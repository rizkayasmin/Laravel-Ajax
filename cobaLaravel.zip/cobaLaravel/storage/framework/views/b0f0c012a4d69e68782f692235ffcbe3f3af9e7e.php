<div class="p2">
  <div class="form-group">
    <input type="text" name="name" id="name" class="form-control" placeholder="name product">
  </div>
  <div class="form-group mt-2">
    <button class="btn btn-success" onClick="store()">Create</button>
  </div>
</div><?php /**PATH C:\xampp\htdocs\cobaLaravel\resources\views/create.blade.php ENDPATH**/ ?>