<div class="p2">
  <div class="form-group">
    <input type="text" name="name" id="name" value="<?php echo e($data->name); ?>" class="form-control" 
    placeholder="name product">
  </div>
  <div class="form-group mt-2">
    <button class="btn btn-warning" onClick="update(<?php echo e($data->id); ?>)">Update</button>
  </div>
</div><?php /**PATH C:\xampp\htdocs\cobaLaravel\resources\views/edit.blade.php ENDPATH**/ ?>